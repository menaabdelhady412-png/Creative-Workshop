#if defined(UNICODE) && !defined(_UNICODE)
#define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
#include <commctrl.h>
#include <sql.h>
#include <sqlext.h>
#include <fstream>
#include <string>

#pragma comment(lib, "odbc32.lib")
#pragma comment(lib, "comctl32.lib")

SQLHENV env;
SQLHDBC dbc;
SQLHSTMT stmt;

HWND hList;
HWND hName;
HWND hEmail;
HWND hPhone;

#define BTN_ADD 100
#define BTN_DELETE 101
#define BTN_EXPORT_HTML 102

std::string GetText(HWND h) {
    char buf[256] = {};
    GetWindowTextA(h, buf, 255);
    return buf;
}

bool ConnectDB() {

    SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &env);

    SQLSetEnvAttr(
        env,
        SQL_ATTR_ODBC_VERSION,
        (void*)SQL_OV_ODBC3,
        0
    );

    SQLAllocHandle(SQL_HANDLE_DBC, env, &dbc);

    std::string conn =
        "DRIVER={ODBC Driver 18 for SQL Server};"
        "SERVER=AHMAD\\ahasa;"
        "DATABASE=ArtStudioDB;"
        "Trusted_Connection=yes;"
        "TrustServerCertificate=yes;";

    SQLRETURN ret = SQLDriverConnectA(
        dbc,
        NULL,
        (SQLCHAR*)conn.c_str(),
        SQL_NTS,
        NULL,
        0,
        NULL,
        SQL_DRIVER_NOPROMPT
    );

    if (ret == SQL_SUCCESS || ret == SQL_SUCCESS_WITH_INFO) {

        SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);

        return true;
    }

    MessageBoxA(
        NULL,
        "SQL Connection Failed",
        "Error",
        MB_ICONERROR
    );

    return false;
}

bool ExecSQL(const std::string& sql) {

    SQLFreeStmt(stmt, SQL_CLOSE);

    SQLRETURN r = SQLExecDirectA(
        stmt,
        (SQLCHAR*)sql.c_str(),
        SQL_NTS
    );

    return r == SQL_SUCCESS || r == SQL_SUCCESS_WITH_INFO;
}

void AddColumn(HWND lv, int i, const char* txt, int w) {

    LVCOLUMNA c = {};

    c.mask = LVCF_TEXT | LVCF_WIDTH;
    c.pszText = (LPSTR)txt;
    c.cx = w;

    ListView_InsertColumn(lv, i, &c);
}

void RefreshMembers() {

    ListView_DeleteAllItems(hList);

    std::string sql =
        "SELECT MEMBERID, MEMBERNAME, MEMBEREMAIL, PHONE "
        "FROM MEMBER";

    if (!ExecSQL(sql))
        return;

    int row = 0;

    while (SQLFetch(stmt) == SQL_SUCCESS) {

        char id[32] = {};
        char name[128] = {};
        char email[128] = {};
        char phone[64] = {};

        SQLGetData(stmt, 1, SQL_C_CHAR, id, 32, NULL);
        SQLGetData(stmt, 2, SQL_C_CHAR, name, 128, NULL);
        SQLGetData(stmt, 3, SQL_C_CHAR, email, 128, NULL);
        SQLGetData(stmt, 4, SQL_C_CHAR, phone, 64, NULL);

        LVITEMA item = {};

        item.mask = LVIF_TEXT;
        item.iItem = row;
        item.pszText = id;

        ListView_InsertItem(hList, &item);

        ListView_SetItemText(hList, row, 1, name);
        ListView_SetItemText(hList, row, 2, email);
        ListView_SetItemText(hList, row, 3, phone);

        row++;
    }

    SQLFreeStmt(stmt, SQL_CLOSE);
}

void AddMember() {

    std::string name = GetText(hName);
    std::string email = GetText(hEmail);
    std::string phone = GetText(hPhone);

    if (name.empty()) {

        MessageBoxA(
            NULL,
            "Enter member name",
            "Warning",
            MB_OK
        );

        return;
    }

    char id[16];

    sprintf(id, "M%05d", rand() % 99999);

    std::string sql =
        "INSERT INTO MEMBER "
        "(MEMBERID, MEMBERNAME, MEMBEREMAIL, PHONE, SUBSCRIPTIONSTATUS) "
        "VALUES ('" +
        std::string(id) + "','" +
        name + "','" +
        email + "','" +
        phone + "','Active')";

    if (ExecSQL(sql)) {

        RefreshMembers();

        SetWindowTextA(hName, "");
        SetWindowTextA(hEmail, "");
        SetWindowTextA(hPhone, "");
    }
}

void DeleteMember() {

    int row = ListView_GetNextItem(
        hList,
        -1,
        LVNI_SELECTED
    );

    if (row == -1)
        return;

    char id[32] = {};

    ListView_GetItemText(
        hList,
        row,
        0,
        id,
        32
    );

    std::string sql =
        "DELETE FROM MEMBER WHERE MEMBERID='" +
        std::string(id) + "'";

    if (ExecSQL(sql)) {

        RefreshMembers();
    }
}

void ExportHTML() {

    std::ofstream file("members.html");

    file << "<html><body>";
    file << "<h1>Members</h1>";
    file << "<table border='1'>";
    file << "<tr>";
    file << "<th>ID</th>";
    file << "<th>Name</th>";
    file << "<th>Email</th>";
    file << "<th>Phone</th>";
    file << "</tr>";

    std::string sql =
        "SELECT MEMBERID, MEMBERNAME, MEMBEREMAIL, PHONE "
        "FROM MEMBER";

    if (ExecSQL(sql)) {

        while (SQLFetch(stmt) == SQL_SUCCESS) {

            char id[32] = {};
            char name[128] = {};
            char email[128] = {};
            char phone[64] = {};

            SQLGetData(stmt, 1, SQL_C_CHAR, id, 32, NULL);
            SQLGetData(stmt, 2, SQL_C_CHAR, name, 128, NULL);
            SQLGetData(stmt, 3, SQL_C_CHAR, email, 128, NULL);
            SQLGetData(stmt, 4, SQL_C_CHAR, phone, 64, NULL);

            file << "<tr>";
            file << "<td>" << id << "</td>";
            file << "<td>" << name << "</td>";
            file << "<td>" << email << "</td>";
            file << "<td>" << phone << "</td>";
            file << "</tr>";
        }
    }

    file << "</table></body></html>";

    file.close();

    MessageBoxA(
        NULL,
        "HTML exported",
        "Done",
        MB_OK
    );
}

LRESULT CALLBACK Proc(
    HWND hwnd,
    UINT msg,
    WPARAM w,
    LPARAM l
) {

    switch (msg) {

    case WM_CREATE:
    {
        InitCommonControls();

        hList = CreateWindowA(
            WC_LISTVIEWA,
            "",
            WS_VISIBLE | WS_CHILD |
            LVS_REPORT | WS_BORDER,
            10,
            10,
            760,
            300,
            hwnd,
            NULL,
            NULL,
            NULL
        );

        ListView_SetExtendedListViewStyle(
            hList,
            LVS_EX_FULLROWSELECT |
            LVS_EX_GRIDLINES
        );

        AddColumn(hList, 0, "ID", 100);
        AddColumn(hList, 1, "Name", 200);
        AddColumn(hList, 2, "Email", 250);
        AddColumn(hList, 3, "Phone", 150);

        hName = CreateWindowA(
            "EDIT",
            "",
            WS_VISIBLE | WS_CHILD | WS_BORDER,
            10,
            330,
            180,
            25,
            hwnd,
            NULL,
            NULL,
            NULL
        );

        hEmail = CreateWindowA(
            "EDIT",
            "",
            WS_VISIBLE | WS_CHILD | WS_BORDER,
            200,
            330,
            220,
            25,
            hwnd,
            NULL,
            NULL,
            NULL
        );

        hPhone = CreateWindowA(
            "EDIT",
            "",
            WS_VISIBLE | WS_CHILD | WS_BORDER,
            430,
            330,
            140,
            25,
            hwnd,
            NULL,
            NULL,
            NULL
        );

        CreateWindowA(
            "BUTTON",
            "Add",
            WS_VISIBLE | WS_CHILD,
            590,
            330,
            80,
            25,
            hwnd,
            (HMENU)BTN_ADD,
            NULL,
            NULL
        );

        CreateWindowA(
            "BUTTON",
            "Delete",
            WS_VISIBLE | WS_CHILD,
            680,
            330,
            80,
            25,
            hwnd,
            (HMENU)BTN_DELETE,
            NULL,
            NULL
        );

        CreateWindowA(
            "BUTTON",
            "Export HTML",
            WS_VISIBLE | WS_CHILD,
            10,
            370,
            140,
            30,
            hwnd,
            (HMENU)BTN_EXPORT_HTML,
            NULL,
            NULL
        );

        if (ConnectDB()) {

            RefreshMembers();
        }

        break;
    }

    case WM_COMMAND:

        switch (LOWORD(w)) {

        case BTN_ADD:
            AddMember();
            break;

        case BTN_DELETE:
            DeleteMember();
            break;

        case BTN_EXPORT_HTML:
            ExportHTML();
            break;
        }

        break;

    case WM_DESTROY:

        PostQuitMessage(0);

        break;
    }

    return DefWindowProc(hwnd, msg, w, l);
}

int WINAPI WinMain(
    HINSTANCE hInst,
    HINSTANCE,
    LPSTR,
    int show
) {

    WNDCLASSA wc = {};

    wc.lpfnWndProc = Proc;
    wc.hInstance = hInst;
    wc.lpszClassName = "ArtStudio";
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClassA(&wc);

    HWND hwnd = CreateWindowA(
        "ArtStudio",
        "ArtStudio Manager",
        WS_OVERLAPPEDWINDOW,
        100,
        100,
        800,
        500,
        NULL,
        NULL,
        hInst,
        NULL
    );

    ShowWindow(hwnd, show);

    MSG msg;

    while (GetMessage(&msg, NULL, 0, 0)) {

        TranslateMessage(&msg);

        DispatchMessage(&msg);
    }

    return 0;
}
