USE ArtStudioDB;
GO

INSERT INTO MEMBER (MEMBERID, MEMBERNAME, MEMBEREMAIL, PHONE, SUBSCRIPTIONSTATUS, SUBSCRIPTIONFEEPAID)
VALUES
    ('M001', 'Alice Johnson', 'alice@example.com', '555-1001', 'Active',  150.00),
    ('M002', 'Bob Smith',     'bob@example.com',   '555-1002', 'Active',  150.00),
    ('M003', 'Carol White',   'carol@example.com', '555-1003', 'Active',    0.00),
    ('M004', 'David Lee',     'david@example.com', '555-1004', 'Active',  200.00),
    ('M005', 'Eva Martinez',  'eva@example.com',   '555-1005', 'Expired', 150.00);
GO

INSERT INTO STUDIO (STUDIOID, STUDIONAME, MAXOCCUPANCY, ROOMNUMBER)
VALUES
    (1, 'Painting Studio',    20, 'A101'),
    (2, 'Sculpture Studio',   15, 'B202'),
    (3, 'Photography Studio', 10, 'C303'),
    (4, 'Ceramics Studio',    12, 'D404');
GO

INSERT INTO RESIDENTARTIST (ARTISTID, RESIDENTNAME, SPECIALTY, RESIDENTEMAIL)
VALUES
    (1, 'Lena Holt',   'Oil Painting', 'lena@artstudio.com'),
    (2, 'Marco Rossi', 'Sculpture',    'marco@artstudio.com'),
    (3, 'Sara Chen',   'Photography',  'sara@artstudio.com'),
    (4, 'James Nkosi', 'Ceramics',     'james@artstudio.com');
GO

INSERT INTO WORKSHOP (WORKSHOPID, STUDIOID, ARTISTID, TITLE, SCHEDULEDATE, CAPACITY)
VALUES
    (1, 1, 1, 'Intro to Oil Painting',   '2026-06-01 10:00:00', 15),
    (2, 2, 2, 'Clay Sculpting Basics',   '2026-06-05 14:00:00', 10),
    (3, 3, 3, 'Portrait Photography',    '2026-06-10 09:00:00',  8),
    (4, 4, 4, 'Wheel Throwing Workshop', '2026-06-15 11:00:00', 10),
    (5, 1, 1, 'Advanced Landscapes',     '2026-06-20 10:00:00', 12);
GO

INSERT INTO TOOL (TOOLID, DESCRIPTION, CONDITION, ISHIGHEND)
VALUES
    (1, 'Professional Easel',  'Excellent', 1),
    (2, 'Sculpting Tool Set',  'Good',      0),
    (3, 'Canon DSLR Camera',   'Excellent', 1),
    (4, 'Pottery Wheel',       'Good',      1),
    (5, 'Acrylic Brush Set',   'Good',      0),
    (6, 'Kiln Gloves',         'Good',      0);
GO

INSERT INTO RAWMATERIAL (MATERIALID, RAWMATERIALNAME, UNITOFMEASURE, STOCKQUANTITY)
VALUES
    (1, 'Linseed Oil',   'Liters',    5.00),
    (2, 'Modeling Clay', 'Kilograms', 20.00),
    (3, 'Photo Paper',   'Sheets',   200.00),
    (4, 'Ceramic Glaze', 'Liters',    8.00),
    (5, 'Canvas Boards', 'Pieces',   30.00),
    (6, 'Acrylic Paint', 'Tubes',    50.00);
GO

INSERT INTO REGISTERS (MEMBERID, WORKSHOPID)
VALUES
    ('M001', 1), ('M001', 3),
    ('M002', 1), ('M002', 2),
    ('M003', 2),
    ('M004', 4),
    ('M005', 5), ('M005', 1);
GO

INSERT INTO BORROWS (MEMBERID, TOOLID)
VALUES
    ('M001', 1),
    ('M001', 5),
    ('M002', 2),
    ('M003', 3),
    ('M004', 4),
    ('M005', 6);
GO

INSERT INTO CONSUMES (WORKSHOPID, MATERIALID)
VALUES
    (1, 1), (1, 5),
    (2, 2),
    (3, 3),
    (4, 2), (4, 4),
    (5, 6);
GO