/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     09/05/2026 23:01:53                          */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('BORROWS') and o.name = 'FK_BORROWS_BORROWS_MEMBER')
alter table BORROWS
   drop constraint FK_BORROWS_BORROWS_MEMBER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('BORROWS') and o.name = 'FK_BORROWS_BORROWS2_TOOL')
alter table BORROWS
   drop constraint FK_BORROWS_BORROWS2_TOOL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONSUMES') and o.name = 'FK_CONSUMES_CONSUMES_WORKSHOP')
alter table CONSUMES
   drop constraint FK_CONSUMES_CONSUMES_WORKSHOP
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONSUMES') and o.name = 'FK_CONSUMES_CONSUMES2_RAWMATER')
alter table CONSUMES
   drop constraint FK_CONSUMES_CONSUMES2_RAWMATER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('REGISTERS') and o.name = 'FK_REGISTER_REGISTERS_MEMBER')
alter table REGISTERS
   drop constraint FK_REGISTER_REGISTERS_MEMBER
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('REGISTERS') and o.name = 'FK_REGISTER_REGISTERS_WORKSHOP')
alter table REGISTERS
   drop constraint FK_REGISTER_REGISTERS_WORKSHOP
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('WORKSHOP') and o.name = 'FK_WORKSHOP_HOSTS_STUDIO')
alter table WORKSHOP
   drop constraint FK_WORKSHOP_HOSTS_STUDIO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('WORKSHOP') and o.name = 'FK_WORKSHOP_INSTRUCTS_RESIDENT')
alter table WORKSHOP
   drop constraint FK_WORKSHOP_INSTRUCTS_RESIDENT
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('BORROWS')
            and   name  = 'BORROWS2_FK'
            and   indid > 0
            and   indid < 255)
   drop index BORROWS.BORROWS2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('BORROWS')
            and   name  = 'BORROWS_FK'
            and   indid > 0
            and   indid < 255)
   drop index BORROWS.BORROWS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BORROWS')
            and   type = 'U')
   drop table BORROWS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONSUMES')
            and   name  = 'CONSUMES2_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONSUMES.CONSUMES2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONSUMES')
            and   name  = 'CONSUMES_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONSUMES.CONSUMES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONSUMES')
            and   type = 'U')
   drop table CONSUMES
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MEMBER')
            and   type = 'U')
   drop table MEMBER
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RAWMATERIAL')
            and   type = 'U')
   drop table RAWMATERIAL
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('REGISTERS')
            and   name  = 'REGISTERS2_FK'
            and   indid > 0
            and   indid < 255)
   drop index REGISTERS.REGISTERS2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('REGISTERS')
            and   name  = 'REGISTERS_FK'
            and   indid > 0
            and   indid < 255)
   drop index REGISTERS.REGISTERS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('REGISTERS')
            and   type = 'U')
   drop table REGISTERS
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RESIDENTARTIST')
            and   type = 'U')
   drop table RESIDENTARTIST
go

if exists (select 1
            from  sysobjects
           where  id = object_id('STUDIO')
            and   type = 'U')
   drop table STUDIO
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TOOL')
            and   type = 'U')
   drop table TOOL
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('WORKSHOP')
            and   name  = 'INSTRUCTS_FK'
            and   indid > 0
            and   indid < 255)
   drop index WORKSHOP.INSTRUCTS_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('WORKSHOP')
            and   name  = 'HOSTS_FK'
            and   indid > 0
            and   indid < 255)
   drop index WORKSHOP.HOSTS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('WORKSHOP')
            and   type = 'U')
   drop table WORKSHOP
go

/*==============================================================*/
/* Table: BORROWS                                               */
/*==============================================================*/
create table BORROWS (
   MEMBERID             varchar(10)          not null,
   TOOLID               int                  not null,
   constraint PK_BORROWS primary key (MEMBERID, TOOLID)
)
go

/*==============================================================*/
/* Index: BORROWS_FK                                            */
/*==============================================================*/
create index BORROWS_FK on BORROWS (
MEMBERID ASC
)
go

/*==============================================================*/
/* Index: BORROWS2_FK                                           */
/*==============================================================*/
create index BORROWS2_FK on BORROWS (
TOOLID ASC
)
go

/*==============================================================*/
/* Table: CONSUMES                                              */
/*==============================================================*/
create table CONSUMES (
   WORKSHOPID           int                  not null,
   MATERIALID           int                  not null,
   constraint PK_CONSUMES primary key (WORKSHOPID, MATERIALID)
)
go

/*==============================================================*/
/* Index: CONSUMES_FK                                           */
/*==============================================================*/
create index CONSUMES_FK on CONSUMES (
WORKSHOPID ASC
)
go

/*==============================================================*/
/* Index: CONSUMES2_FK                                          */
/*==============================================================*/
create index CONSUMES2_FK on CONSUMES (
MATERIALID ASC
)
go

/*==============================================================*/
/* Table: MEMBER                                                */
/*==============================================================*/
create table MEMBER (
   MEMBERID             varchar(10)          not null,
   MEMBERNAME           varchar(100)         null,
   MEMBEREMAIL          varchar(255)         null,
   PHONE                varchar(20)          null,
   SUBSCRIPTIONSTATUS   varchar(20)          null default 'Active'
      constraint CKC_SUBSCRIPTIONSTATU_MEMBER check (SUBSCRIPTIONSTATUS is null or (SUBSCRIPTIONSTATUS in ('Active','Expired','Cancelled'))),
   SUBSCRIPTIONFEEPAID  decimal(10,2)        null,
   constraint PK_MEMBER primary key nonclustered (MEMBERID)
)
go

/*==============================================================*/
/* Table: RAWMATERIAL                                           */
/*==============================================================*/
create table RAWMATERIAL (
   MATERIALID           int                  not null,
   RAWMATERIALNAME      varchar(50)          null,
   UNITOFMEASURE        varchar(20)          null,
   STOCKQUANTITY        decimal(10,2)        null,
   constraint PK_RAWMATERIAL primary key nonclustered (MATERIALID)
)
go

/*==============================================================*/
/* Table: REGISTERS                                             */
/*==============================================================*/
create table REGISTERS (
   MEMBERID             varchar(10)          not null,
   WORKSHOPID           int                  not null,
   constraint PK_REGISTERS primary key (MEMBERID, WORKSHOPID)
)
go

/*==============================================================*/
/* Index: REGISTERS_FK                                          */
/*==============================================================*/
create index REGISTERS_FK on REGISTERS (
MEMBERID ASC
)
go

/*==============================================================*/
/* Index: REGISTERS2_FK                                         */
/*==============================================================*/
create index REGISTERS2_FK on REGISTERS (
WORKSHOPID ASC
)
go

/*==============================================================*/
/* Table: RESIDENTARTIST                                        */
/*==============================================================*/
create table RESIDENTARTIST (
   ARTISTID             int                  not null,
   RESIDENTNAME         varchar(100)         null,
   SPECIALTY            varchar(50)          null,
   RESIDENTEMAIL        varchar(255)         null,
   constraint PK_RESIDENTARTIST primary key nonclustered (ARTISTID)
)
go

/*==============================================================*/
/* Table: STUDIO                                                */
/*==============================================================*/
create table STUDIO (
   STUDIOID             int                  not null,
   STUDIONAME           varchar(50)          null,
   MAXOCCUPANCY         int                  null,
   ROOMNUMBER           varchar(20)          null,
   constraint PK_STUDIO primary key nonclustered (STUDIOID)
)
go

/*==============================================================*/
/* Table: TOOL                                                  */
/*==============================================================*/
create table TOOL (
   TOOLID               int                  not null,
   DESCRIPTION          varchar(255)         null,
   CONDITION            varchar(30)          null default 'Excellent'
      constraint CKC_CONDITION_TOOL check (CONDITION is null or (CONDITION in ('Excellent','Good','Needs Repair'))),
   ISHIGHEND            smallint             null,
   constraint PK_TOOL primary key nonclustered (TOOLID)
)
go

/*==============================================================*/
/* Table: WORKSHOP                                              */
/*==============================================================*/
create table WORKSHOP (
   WORKSHOPID           int                  not null,
   STUDIOID             int                  not null,
   ARTISTID             int                  not null,
   TITLE                varchar(100)         null,
   SCHEDULEDATE         datetime             null,
   CAPACITY             int                  null,
   constraint PK_WORKSHOP primary key nonclustered (WORKSHOPID)
)
go

/*==============================================================*/
/* Index: HOSTS_FK                                              */
/*==============================================================*/
create index HOSTS_FK on WORKSHOP (
STUDIOID ASC
)
go

/*==============================================================*/
/* Index: INSTRUCTS_FK                                          */
/*==============================================================*/
create index INSTRUCTS_FK on WORKSHOP (
ARTISTID ASC
)
go

alter table BORROWS
   add constraint FK_BORROWS_BORROWS_MEMBER foreign key (MEMBERID)
      references MEMBER (MEMBERID)
go

alter table BORROWS
   add constraint FK_BORROWS_BORROWS2_TOOL foreign key (TOOLID)
      references TOOL (TOOLID)
go

alter table CONSUMES
   add constraint FK_CONSUMES_CONSUMES_WORKSHOP foreign key (WORKSHOPID)
      references WORKSHOP (WORKSHOPID)
go

alter table CONSUMES
   add constraint FK_CONSUMES_CONSUMES2_RAWMATER foreign key (MATERIALID)
      references RAWMATERIAL (MATERIALID)
go

alter table REGISTERS
   add constraint FK_REGISTER_REGISTERS_MEMBER foreign key (MEMBERID)
      references MEMBER (MEMBERID)
go

alter table REGISTERS
   add constraint FK_REGISTER_REGISTERS_WORKSHOP foreign key (WORKSHOPID)
      references WORKSHOP (WORKSHOPID)
go

alter table WORKSHOP
   add constraint FK_WORKSHOP_HOSTS_STUDIO foreign key (STUDIOID)
      references STUDIO (STUDIOID)
go

alter table WORKSHOP
   add constraint FK_WORKSHOP_INSTRUCTS_RESIDENT foreign key (ARTISTID)
      references RESIDENTARTIST (ARTISTID)
go

